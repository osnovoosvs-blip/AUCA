package dev.rtpauction;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public final class AuctionGui implements Listener {
    public enum Mode { ALL, MINE }

    private static final int PER_PAGE = 45;

    private static final class Holder implements InventoryHolder {
        final Mode mode;
        final int page;
        Inventory inv;

        Holder(Mode mode, int page) {
            this.mode = mode;
            this.page = page;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final RtpAuctionPlugin plugin;
    private final NamespacedKey idKey;
    private final NamespacedKey actionKey;

    public AuctionGui(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
        this.idKey = new NamespacedKey(plugin, "listing_id");
        this.actionKey = new NamespacedKey(plugin, "action");
    }

    public void open(Player p, Mode mode, int page) {
        Messages m = plugin.messages();
        AuctionManager am = plugin.auction();
        List<AuctionManager.Listing> list = mode == Mode.ALL ? am.all() : am.byPlayer(p.getUniqueId());
        int pages = Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));

        Holder h = new Holder(mode, page);
        Component title = m.component(mode == Mode.ALL ? "gui-title" : "gui-title-mine")
                .append(Component.text(" (" + (page + 1) + "/" + pages + ")"));
        Inventory inv = Bukkit.createInventory(h, 54, title);
        h.inv = inv;

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= list.size()) break;
            inv.setItem(i, display(list.get(idx), mode));
        }

        ItemStack filler = button(Material.GRAY_STAINED_GLASS_PANE, " ", null);
        for (int s = 45; s < 54; s++) inv.setItem(s, filler);
        if (page > 0) inv.setItem(45, button(Material.ARROW, m.raw("gui-prev"), "prev"));
        if (page < pages - 1) inv.setItem(53, button(Material.ARROW, m.raw("gui-next"), "next"));
        inv.setItem(49, mode == Mode.ALL
                ? button(Material.CHEST, m.raw("gui-mine"), "toggle")
                : button(Material.BOOK, m.raw("gui-all"), "toggle"));

        p.openInventory(inv);
    }

    private ItemStack display(AuctionManager.Listing l, Mode mode) {
        Messages m = plugin.messages();
        ItemStack it = l.item().clone();
        ItemMeta meta = it.getItemMeta();
        if (meta == null) return it;

        List<Component> lore = new ArrayList<>();
        if (meta.lore() != null) lore.addAll(meta.lore());
        long minutes = Math.max(0, (l.expiresAt() - System.currentTimeMillis()) / 60_000L);
        String price = plugin.economy() != null ? plugin.economy().format(l.price()) : String.valueOf(l.price());

        lore.add(Component.empty());
        lore.add(m.plain("gui-lore-price", "price", price));
        lore.add(m.plain("gui-lore-seller", "seller", l.sellerName()));
        lore.add(m.plain("gui-lore-expires", "left", (minutes / 60) + "ч " + (minutes % 60) + "м"));
        lore.add(m.plain(mode == Mode.ALL ? "gui-lore-buy" : "gui-lore-cancel"));
        meta.lore(lore);
        meta.getPersistentDataContainer().set(idKey, PersistentDataType.LONG, l.id());
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack button(Material mat, String legacyName, String action) {
        ItemStack it = new ItemStack(mat);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(plugin.messages().legacy(legacyName));
        if (action != null) meta.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, action);
        it.setItemMeta(meta);
        return it;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof Holder h)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;
        ItemStack it = e.getCurrentItem();
        if (it == null || !it.hasItemMeta()) return;

        PersistentDataContainer pdc = it.getItemMeta().getPersistentDataContainer();
        String action = pdc.get(actionKey, PersistentDataType.STRING);
        if (action != null) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                switch (action) {
                    case "prev" -> open(p, h.mode, h.page - 1);
                    case "next" -> open(p, h.mode, h.page + 1);
                    case "toggle" -> open(p, h.mode == Mode.ALL ? Mode.MINE : Mode.ALL, 0);
                    default -> { }
                }
            });
            return;
        }

        Long id = pdc.get(idKey, PersistentDataType.LONG);
        if (id == null) return;
        if (!e.isLeftClick()) return;
        long listingId = id;
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (h.mode == Mode.ALL) plugin.auction().buy(p, listingId);
            else plugin.auction().cancel(p, listingId);
            open(p, h.mode, h.page);
        });
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof Holder) e.setCancelled(true);
    }
}
