package dev.rtpauction;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;

import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/** Деньги за убийство мобов. Суммы по типам мобов — в config.yml (mob-rewards.amounts). */
public final class MobRewardListener implements Listener {
    private final RtpAuctionPlugin plugin;

    public MobRewardListener(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent e) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("mob-rewards.enabled", true)) return;

        LivingEntity mob = e.getEntity();
        if (mob instanceof Player) return;
        Player killer = mob.getKiller();
        if (killer == null || !killer.hasPermission("rtpauction.mobreward")) return;

        Economy eco = plugin.economy();
        if (eco == null) return;

        if (c.getBoolean("mob-rewards.ignore-spawner-mobs", true) && mob.fromMobSpawner()) return;
        var worlds = c.getStringList("mob-rewards.worlds");
        if (!worlds.isEmpty() && !worlds.contains(mob.getWorld().getName())) return;

        double amount = rollAmount(mob.getType().name());
        amount = Math.round(amount * 100.0) / 100.0;
        if (amount <= 0) return;

        if (!eco.depositPlayer(killer, amount).transactionSuccess()) return;

        if (c.getBoolean("mob-rewards.show-actionbar", true)) {
            killer.sendActionBar(plugin.messages().plain("mob-reward",
                    "amount", eco.format(amount),
                    "mob", mob.getType().name().toLowerCase(Locale.ROOT).replace('_', ' ')));
        }
    }

    /** Значение: число (5 / 2.5) или диапазон ("5-10"). Нет в списке — mob-rewards.default. */
    private double rollAmount(String typeName) {
        FileConfiguration c = plugin.getConfig();
        double def = c.getDouble("mob-rewards.default", 0.0);
        ConfigurationSection amounts = c.getConfigurationSection("mob-rewards.amounts");
        if (amounts == null) return def;

        Object v = amounts.get(typeName);
        if (v == null) v = amounts.get(typeName.toLowerCase(Locale.ROOT));
        if (v == null) return def;

        try {
            if (v instanceof Number n) return Math.max(0, n.doubleValue());
            String s = v.toString().trim().replace(',', '.');
            int dash = s.indexOf('-', 1);
            if (dash > 0) {
                double a = Double.parseDouble(s.substring(0, dash).trim());
                double b = Double.parseDouble(s.substring(dash + 1).trim());
                double lo = Math.max(0, Math.min(a, b));
                double hi = Math.max(0, Math.max(a, b));
                return lo == hi ? lo : ThreadLocalRandom.current().nextDouble(lo, hi);
            }
            return Math.max(0, Double.parseDouble(s));
        } catch (NumberFormatException ex) {
            plugin.getLogger().warning("Неверная сумма для " + typeName + " в mob-rewards.amounts: " + v);
            return def;
        }
    }
}
