package dev.rtpauction;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** /ahnpc set — поставить NPC-аукциониста на своё место; /ahnpc remove — убрать. */
public final class NpcCommand implements CommandExecutor {
    private final RtpAuctionPlugin plugin;

    public NpcCommand(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Messages m = plugin.messages();
        if (!(sender instanceof Player p)) {
            m.send(sender, "players-only");
            return true;
        }
        String sub = args.length == 0 ? "set" : args[0].toLowerCase();
        switch (sub) {
            case "remove" -> {
                if (plugin.npc().remove()) m.send(p, "npc-removed");
                else m.send(p, "npc-none");
            }
            case "set" -> {
                Location loc = p.getLocation();
                plugin.npc().place(loc);
                m.send(p, "npc-set",
                        "x", String.valueOf(loc.getBlockX()),
                        "y", String.valueOf(loc.getBlockY()),
                        "z", String.valueOf(loc.getBlockZ()));
            }
            default -> m.send(p, "npc-usage");
        }
        return true;
    }
}
