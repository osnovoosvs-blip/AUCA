package dev.rtpauction;

import com.sun.net.httpserver.HttpServer;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URI;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.concurrent.Executors;

/**
 * Ресурспак со скином NPC лежит внутри jar. Плагин сам раздаёт его по встроенному HTTP-серверу
 * и отправляет игрокам при входе — ничего вручную загружать/прописывать не нужно.
 */
public final class ResourcePackManager implements Listener {
    private static final String RESOURCE = "AuctionNpcSkin_resourcepack.zip";
    private static final String PATH = "/rtpauction-npc.zip";

    private final RtpAuctionPlugin plugin;
    private HttpServer server;
    private byte[] sha1;
    private UUID packId;
    private volatile String url;

    public ResourcePackManager(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        var c = plugin.getConfig();
        if (!c.getBoolean("resource-pack.enabled", true)) return;

        byte[] data;
        try (InputStream in = plugin.getResource(RESOURCE)) {
            if (in == null) {
                plugin.getLogger().warning("Ресурспак не найден внутри jar: " + RESOURCE);
                return;
            }
            data = in.readAllBytes();
            sha1 = MessageDigest.getInstance("SHA-1").digest(data);
        } catch (Exception ex) {
            plugin.getLogger().warning("Не удалось прочитать ресурспак: " + ex.getMessage());
            return;
        }
        packId = UUID.nameUUIDFromBytes(sha1);

        String custom = c.getString("resource-pack.url", "");
        if (!custom.isBlank()) { // свой хостинг: пак из jar выложен по этой ссылке
            url = custom;
            return;
        }

        int port = c.getInt("resource-pack.port", 25580);
        try {
            server = HttpServer.create(new InetSocketAddress(port), 0);
            server.createContext(PATH, ex -> {
                ex.getResponseHeaders().add("Content-Type", "application/zip");
                ex.sendResponseHeaders(200, data.length);
                try (OutputStream os = ex.getResponseBody()) {
                    os.write(data);
                }
            });
            server.setExecutor(Executors.newFixedThreadPool(2));
            server.start();
        } catch (Exception ex) {
            plugin.getLogger().warning("Не удалось запустить раздачу ресурспака на порту " + port + ": " + ex.getMessage());
            server = null;
            return;
        }

        String host = c.getString("resource-pack.host", "");
        if (!host.isBlank()) {
            url = "http://" + host + ":" + port + PATH;
            plugin.getLogger().info("Ресурспак раздаётся по адресу " + url);
        } else {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                String ip = detectPublicIp();
                url = "http://" + ip + ":" + port + PATH;
                plugin.getLogger().info("Ресурспак раздаётся по адресу " + url
                        + " (порт " + port + "/TCP должен быть открыт; иначе задайте resource-pack.host)");
            });
        }
    }

    public void stop() {
        if (server != null) server.stop(0);
    }

    private String detectPublicIp() {
        try {
            HttpURLConnection con = (HttpURLConnection) URI.create("https://api.ipify.org").toURL().openConnection();
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            try (InputStream in = con.getInputStream()) {
                String ip = new String(in.readAllBytes()).trim();
                if (!ip.isEmpty()) return ip;
            }
        } catch (Exception ignored) {
        }
        String ip = Bukkit.getIp();
        return ip == null || ip.isBlank() ? "127.0.0.1" : ip;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (sha1 == null || packId == null) return;
        var p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            String u = url;
            if (u == null || !p.isOnline()) return;
            var c = plugin.getConfig();
            String prompt = LegacyComponentSerializer.legacySection().serialize(
                    LegacyComponentSerializer.legacyAmpersand()
                            .deserialize(c.getString("resource-pack.prompt", "&6Скин аукциониста")));
            p.addResourcePack(packId, u, sha1, prompt, c.getBoolean("resource-pack.force", false));
        }, 20L);
    }
}
