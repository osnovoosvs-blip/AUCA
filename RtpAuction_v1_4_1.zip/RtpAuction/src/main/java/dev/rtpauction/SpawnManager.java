package dev.rtpauction;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Точка спавна (/setspawn, /spawn). Хранится в spawn.yml, чтобы не затирать комментарии config.yml. */
public final class SpawnManager implements Listener {
    private final RtpAuctionPlugin plugin;
    private final File file;
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> pending = new HashSet<>();

    private boolean set;
    private String worldName;
    private double x, y, z;
    private float yaw, pitch;

    public SpawnManager(RtpAuctionPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "spawn.yml");
        load();
    }

    // ---------- хранение ----------

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration cfg = YamlConfiguration.loadConfiguration(file);
        worldName = cfg.getString("world");
        if (worldName == null) return;
        x = cfg.getDouble("x");
        y = cfg.getDouble("y");
        z = cfg.getDouble("z");
        yaw = (float) cfg.getDouble("yaw");
        pitch = (float) cfg.getDouble("pitch");
        set = true;
    }

    private void save() {
        YamlConfiguration cfg = new YamlConfiguration();
        cfg.set("world", worldName);
        cfg.set("x", x);
        cfg.set("y", y);
        cfg.set("z", z);
        cfg.set("yaw", (double) yaw);
        cfg.set("pitch", (double) pitch);
        try {
            plugin.getDataFolder().mkdirs();
            cfg.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Не удалось сохранить spawn.yml: " + ex.getMessage());
        }
    }

    // ---------- точка спавна ----------

    public void setSpawn(Location loc) {
        worldName = loc.getWorld().getName();
        x = loc.getX();
        y = loc.getY();
        z = loc.getZ();
        yaw = loc.getYaw();
        pitch = loc.getPitch();
        set = true;
        save();
    }

    /** Заданный спавн; если не задан (или его мир не загружен) — спавн основного мира, если это разрешено в конфиге. */
    public Location resolve() {
        if (set) {
            World w = Bukkit.getWorld(worldName);
            if (w != null) return new Location(w, x, y, z, yaw, pitch);
        }
        if (plugin.getConfig().getBoolean("spawn.fallback-to-world-spawn", true) && !Bukkit.getWorlds().isEmpty()) {
            return Bukkit.getWorlds().get(0).getSpawnLocation().add(0.5, 0, 0.5);
        }
        return null;
    }

    // ---------- /spawn ----------

    public void request(Player player) {
        Messages m = plugin.messages();
        UUID id = player.getUniqueId();

        if (resolve() == null) {
            m.send(player, "spawn-not-set");
            return;
        }
        if (pending.contains(id)) {
            m.send(player, "spawn-already");
            return;
        }
        boolean bypass = player.hasPermission("rtpauction.spawn.bypass");
        if (!bypass) {
            long left = cooldowns.getOrDefault(id, 0L) - System.currentTimeMillis();
            if (left > 0) {
                m.send(player, "spawn-cooldown", "seconds", String.valueOf((left + 999) / 1000));
                return;
            }
        }

        int warmup = bypass ? 0 : plugin.getConfig().getInt("spawn.warmup-seconds", 0);
        pending.add(id);
        if (warmup <= 0) {
            teleport(player);
            return;
        }
        m.send(player, "spawn-warmup", "seconds", String.valueOf(warmup));
        Location start = player.getLocation().clone();
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) {
                pending.remove(id);
                return;
            }
            Location now = player.getLocation();
            if (now.getWorld() != start.getWorld() || now.distanceSquared(start) > 1.0) {
                pending.remove(id);
                m.send(player, "spawn-moved");
                return;
            }
            teleport(player);
        }, warmup * 20L);
    }

    private void teleport(Player player) {
        UUID id = player.getUniqueId();
        Messages m = plugin.messages();
        Location dest = resolve();
        if (dest == null) {
            pending.remove(id);
            m.send(player, "spawn-not-set");
            return;
        }
        player.teleportAsync(dest).thenAccept(ok -> Bukkit.getScheduler().runTask(plugin, () -> {
            pending.remove(id);
            if (!ok) {
                m.send(player, "spawn-failed");
                return;
            }
            long cd = plugin.getConfig().getLong("spawn.cooldown-seconds", 0) * 1000L;
            if (cd > 0) cooldowns.put(id, System.currentTimeMillis() + cd);
            m.send(player, "spawn-success");
        }));
    }

    // ---------- события ----------

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        if (e.getPlayer().hasPlayedBefore()) return;
        if (!plugin.getConfig().getBoolean("spawn.teleport-on-first-join", true)) return;
        Location dest = resolve();
        if (dest != null) e.getPlayer().teleportAsync(dest);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        if (!plugin.getConfig().getBoolean("spawn.teleport-on-respawn", true)) return;
        if (e.isBedSpawn() || e.isAnchorSpawn()) return; // кровать/якорь важнее
        Location dest = resolve();
        if (dest != null) e.setRespawnLocation(dest);
    }
}
